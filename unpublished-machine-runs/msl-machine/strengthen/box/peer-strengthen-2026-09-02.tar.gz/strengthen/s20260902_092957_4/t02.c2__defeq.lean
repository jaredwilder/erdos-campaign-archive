import Mathlib

set_option autoImplicit false
set_option maxRecDepth 4000

open Finset

-- campaign vocabulary, already kernel-checked (msl_decompose)
def runSum (a b : ℕ) : ℚ := ∑ n ∈ Icc a b, (1 : ℚ) / n

def runProd (a b : ℕ) : ℕ := ∏ n ∈ Icc a b, n

def runNum (a b : ℕ) : ℕ := ∑ n ∈ Icc a b, runProd a b / n

-- proposed definitions

abbrev msl_p_erdos289_a_m01_d2 (n : Nat) : Prop :=
  2 ≤ n → (n + 1) + 1 < n * (n + 1)

abbrev msl_q_erdos289_a_m01_d2_s2 (n : Nat) : Prop :=
  (2 ≤ n) → ((n + 2 : Nat) < n * (n + 1) ∧ 4 ≤ n * n)
example : (∀ (n : Nat), msl_q_erdos289_a_m01_d2_s2 n) = (∀ (n : Nat), msl_p_erdos289_a_m01_d2 n) := by
  first
  | rfl
  | fail "MSL_NOT_DEFEQ"
